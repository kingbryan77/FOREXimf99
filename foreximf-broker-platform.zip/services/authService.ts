import { User, UserWithPassword } from '../types';
import { MOCK_USERS } from '../constants';

const LOCAL_STORAGE_USERS_KEY = 'foreximf_users';
const LOCAL_STORAGE_CURRENT_USER_ID_KEY = 'foreximf_current_user_id';

// Initialization logic that runs once when the module is first imported.
// This ensures a stable and reliable initial state for user data.
(() => {
  const usersJson = localStorage.getItem(LOCAL_STORAGE_USERS_KEY);
  let needsSeeding = false;

  if (!usersJson) {
    needsSeeding = true;
    console.log('User storage not found. Seeding mock users.');
  } else {
    try {
      const users = JSON.parse(usersJson);
      if (!Array.isArray(users) || users.length === 0) {
        needsSeeding = true;
        console.log('User storage is empty or invalid. Re-seeding mock users.');
      }
    } catch (e) {
      needsSeeding = true;
      console.error('Failed to parse user storage. Re-seeding mock users.', e);
    }
  }

  if (needsSeeding) {
    localStorage.setItem(LOCAL_STORAGE_USERS_KEY, JSON.stringify(MOCK_USERS));
  }
})();


const getStoredUsers = (): UserWithPassword[] => {
  const usersJson = localStorage.getItem(LOCAL_STORAGE_USERS_KEY);
  // This should not happen because of the initializer, but as a fallback:
  if (!usersJson) {
    return [];
  }
  try {
    return JSON.parse(usersJson);
  } catch {
    // This should also not happen.
    return [];
  }
};

const setStoredUsers = (users: UserWithPassword[]): void => {
  localStorage.setItem(LOCAL_STORAGE_USERS_KEY, JSON.stringify(users));
};


export const register = async (userData: Omit<User, 'id' | 'username' | 'isAdmin' | 'isVerified' | 'balance' | 'notifications' | 'profilePictureUrl'> & { password: string }): Promise<User | null> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const users = getStoredUsers();

      // Check for unique email
      if (users.some(u => u.email === userData.email)) {
        console.error('Registration failed: Email already exists.');
        resolve(null);
        return;
      }

      // Basic password strength check
      if (userData.password.length < 6) {
        console.error('Registration failed: Password too short.');
        resolve(null);
        return;
      }

      // Generate username from email
      const username = userData.email.split('@')[0].toLowerCase();

      const newUserWithPassword: UserWithPassword = {
        id: `user-${Date.now()}`,
        fullName: userData.fullName,
        username: username,
        email: userData.email,
        phoneNumber: userData.phoneNumber,
        isAdmin: false,
        isVerified: false, // Requires email verification
        balance: 13000000, // New users start with default balance
        notifications: [],
        profilePictureUrl: undefined,
        password: userData.password,
      };

      users.push(newUserWithPassword);
      setStoredUsers(users);

      console.log('User registered successfully. Email verification required.');
      // Return User without password
      const { password, ...newUserWithoutPassword } = newUserWithPassword;
      resolve(newUserWithoutPassword);
    }, 500);
  });
};

export const login = async (identifier: string, passwordAttempt: string): Promise<User | null> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const users = getStoredUsers();
      const userFound = users.find(u =>
        (u.email === identifier || u.phoneNumber === identifier || u.username === identifier) && u.password === passwordAttempt
      );

      if (userFound) {
        // isVerified check is now handled by the activation alert, allowing unverified users to log in.
        localStorage.setItem(LOCAL_STORAGE_CURRENT_USER_ID_KEY, userFound.id);
        console.log('Login successful:', userFound.email);
        const { password, ...userWithoutPassword } = userFound;
        resolve(userWithoutPassword);
      } else {
        console.error('Login failed: Invalid credentials or account not found.');
        resolve(null);
      }
    }, 500);
  });
};

export const logout = (): void => {
  localStorage.removeItem(LOCAL_STORAGE_CURRENT_USER_ID_KEY);
  console.log('Logged out.');
};

export const getCurrentUser = (): User | null => {
  const currentUserId = localStorage.getItem(LOCAL_STORAGE_CURRENT_USER_ID_KEY);
  if (currentUserId) {
    const users = getStoredUsers();
    const userFound = users.find(u => u.id === currentUserId);
    if (userFound) {
      // Return User without password
      const { password, ...userWithoutPassword } = userFound;
      return userWithoutPassword;
    }
  }
  return null;
};

export const verifyEmail = async (email: string): Promise<boolean> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const users = getStoredUsers();
      const userIndex = users.findIndex(u => u.email === email);
      if (userIndex > -1) {
        users[userIndex].isVerified = true;
        setStoredUsers(users);
        console.log(`Email for ${email} verified successfully.`);
        resolve(true);
      } else {
        console.error('Verification failed: User not found.');
        resolve(false);
      }
    }, 500);
  });
};

export const updateUserNotification = (userId: string, notificationId: string, read: boolean): void => {
  const users = getStoredUsers();
  const userIndex = users.findIndex(u => u.id === userId);
  if (userIndex > -1) {
    const notificationIndex = users[userIndex].notifications.findIndex(n => n.id === notificationId);
    if (notificationIndex > -1) {
      users[userIndex].notifications[notificationIndex].read = read;
      setStoredUsers(users);
    }
  }
};

export const addUserNotification = (userId: string, message: string): void => {
  const users = getStoredUsers();
  const userIndex = users.findIndex(u => u.id === userId);
  if (userIndex > -1) {
    const newNotification = {
      id: `notif-${Date.now()}`,
      userId,
      message,
      date: new Date().toISOString(),
      read: false,
    };
    users[userIndex].notifications.unshift(newNotification); // Add to beginning
    setStoredUsers(users);
  }
};

export const updateUserBalance = (userId: string, newBalance: number): void => {
  const users = getStoredUsers();
  const userIndex = users.findIndex(u => u.id === userId);
  if (userIndex > -1) {
    users[userIndex].balance = newBalance;
    setStoredUsers(users);
  }
};

export const getAllUsers = (): User[] => {
  // Return users without passwords
  return getStoredUsers().map(user => {
    const { password, ...rest } = user;
    return rest;
  });
};

export const updateUserInfo = (updatedUser: Partial<User>): void => { // updatedUser is Partial<User>
  const users = getStoredUsers();
  const userIndex = users.findIndex(u => u.id === updatedUser.id);
  if (userIndex > -1) {
    const currentUser = users[userIndex];
    // Preserve password and merge other updated fields
    users[userIndex] = { ...currentUser, ...updatedUser };
    setStoredUsers(users);
  }
};