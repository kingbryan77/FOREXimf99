import {
  Transaction,
  DepositTransaction,
  WithdrawalTransaction,
  TransactionType,
  TransactionStatus,
  CompanyBankInfo,
  User,
} from '../types';
import { MOCK_DEPOSITS, MOCK_WITHDRAWALS, DEFAULT_COMPANY_BANK_INFO } from '../constants';
import { addUserNotification, updateUserBalance, getCurrentUser, updateUserInfo, getAllUsers } from './authService';

const LOCAL_STORAGE_DEPOSITS_KEY = 'foreximf_deposits';
const LOCAL_STORAGE_WITHDRAWALS_KEY = 'foreximf_withdrawals';
const LOCAL_STORAGE_COMPANY_BANK_INFO_KEY = 'foreximf_company_bank_info';

const getStoredDeposits = (): DepositTransaction[] => {
  const depositsJson = localStorage.getItem(LOCAL_STORAGE_DEPOSITS_KEY);
  return depositsJson ? JSON.parse(depositsJson) : [...MOCK_DEPOSITS];
};

const setStoredDeposits = (deposits: DepositTransaction[]): void => {
  localStorage.setItem(LOCAL_STORAGE_DEPOSITS_KEY, JSON.stringify(deposits));
};

const getStoredWithdrawals = (): WithdrawalTransaction[] => {
  const withdrawalsJson = localStorage.getItem(LOCAL_STORAGE_WITHDRAWALS_KEY);
  return withdrawalsJson ? JSON.parse(withdrawalsJson) : [...MOCK_WITHDRAWALS];
};

const setStoredWithdrawals = (withdrawals: WithdrawalTransaction[]): void => {
  localStorage.setItem(LOCAL_STORAGE_WITHDRAWALS_KEY, JSON.stringify(withdrawals));
};

export const getCompanyBankInfo = (): CompanyBankInfo => {
  const bankInfoJson = localStorage.getItem(LOCAL_STORAGE_COMPANY_BANK_INFO_KEY);
  return bankInfoJson ? JSON.parse(bankInfoJson) : DEFAULT_COMPANY_BANK_INFO;
};

export const setCompanyBankInfo = (info: CompanyBankInfo): void => {
  localStorage.setItem(LOCAL_STORAGE_COMPANY_BANK_INFO_KEY, JSON.stringify(info));
};

export const deposit = async (userId: string, amount: number): Promise<boolean> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const deposits = getStoredDeposits();
      const companyBankInfo = getCompanyBankInfo();
      const newDeposit: DepositTransaction = {
        id: `dep-${Date.now()}`,
        userId,
        type: TransactionType.DEPOSIT,
        amount,
        method: 'Bank Transfer', // Assuming only bank transfer for simplicity
        status: TransactionStatus.PENDING,
        date: new Date().toISOString(),
        companyBankInfo: companyBankInfo,
      };
      deposits.unshift(newDeposit); // Add to beginning
      setStoredDeposits(deposits);
      addUserNotification(userId, `Your deposit of Rp ${amount.toLocaleString('id-ID')} is pending.`);
      console.log('Deposit initiated:', newDeposit);
      resolve(true);
    }, 1000);
  });
};

export const withdraw = async (
  userId: string,
  amount: number,
  method: string,
  bankOrEwalletName: string,
  accountNumber: string,
  accountHolderName: string,
): Promise<boolean> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const currentUser = getCurrentUser();
      if (!currentUser || currentUser.balance < amount) {
        console.error('Withdrawal failed: Insufficient balance or user not found.');
        resolve(false);
        return;
      }

      // Immediately reduce balance
      const newBalance = currentUser.balance - amount;
      updateUserBalance(userId, newBalance); // This updates the balance in local storage
      addUserNotification(userId, `Your balance has been reduced by Rp ${amount.toLocaleString('id-ID')} for a pending withdrawal.`);


      const withdrawals = getStoredWithdrawals();
      const newWithdrawal: WithdrawalTransaction = {
        id: `wit-${Date.now()}`,
        userId,
        type: TransactionType.WITHDRAWAL,
        amount,
        method,
        bankOrEwalletName,
        accountNumber,
        accountHolderName,
        status: TransactionStatus.PENDING,
        date: new Date().toISOString(),
      };
      withdrawals.unshift(newWithdrawal); // Add to beginning
      setStoredWithdrawals(withdrawals);

      console.log('Withdrawal initiated:', newWithdrawal);
      resolve(true);
    }, 1000);
  });
};

export const getDepositHistory = (userId: string): DepositTransaction[] => {
  return getStoredDeposits().filter(t => t.userId === userId).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const getWithdrawalHistory = (userId: string): WithdrawalTransaction[] => {
  return getStoredWithdrawals().filter(t => t.userId === userId).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const getAllTransactions = (): Transaction[] => {
  const allDeposits = getStoredDeposits();
  const allWithdrawals = getStoredWithdrawals();
  return [...allDeposits, ...allWithdrawals].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const updateDepositStatus = (depositId: string, status: TransactionStatus): boolean => {
  const deposits = getStoredDeposits();
  const depositIndex = deposits.findIndex(d => d.id === depositId);
  if (depositIndex > -1) {
    const deposit = deposits[depositIndex];
    if (deposit.status !== TransactionStatus.SUCCESS && status === TransactionStatus.SUCCESS) {
      // If changing to SUCCESS, update user's balance
      const users = getAllUsers();
      const user = users.find(u => u.id === deposit.userId);
      if (user) {
        updateUserBalance(user.id, user.balance + deposit.amount);
        addUserNotification(user.id, `Your deposit of Rp ${deposit.amount.toLocaleString('id-ID')} is successful!`);
      }
    } else if (deposit.status === TransactionStatus.SUCCESS && status !== TransactionStatus.SUCCESS) {
        // If changing from SUCCESS to another status, revert balance
        const users = getAllUsers();
        const user = users.find(u => u.id === deposit.userId);
        if (user) {
          updateUserBalance(user.id, user.balance - deposit.amount);
          addUserNotification(user.id, `Your deposit of Rp ${deposit.amount.toLocaleString('id-ID')} has been reverted to ${status}.`);
        }
    }
    deposits[depositIndex].status = status;
    setStoredDeposits(deposits);
    addUserNotification(deposit.userId, `Your deposit #${depositId} status updated to ${status}.`);
    return true;
  }
  return false;
};

export const updateWithdrawalStatus = (withdrawalId: string, status: TransactionStatus): boolean => {
  const withdrawals = getStoredWithdrawals();
  const withdrawalIndex = withdrawals.findIndex(w => w.id === withdrawalId);
  if (withdrawalIndex > -1) {
    const withdrawal = withdrawals[withdrawalIndex];
    // If a withdrawal is cancelled/rejected and was previously pending, revert the balance
    if (withdrawal.status === TransactionStatus.PENDING && (status === TransactionStatus.REJECTED || status === TransactionStatus.CANCELLED)) {
      const users = getAllUsers();
      const user = users.find(u => u.id === withdrawal.userId);
      if (user) {
        updateUserBalance(user.id, user.balance + withdrawal.amount);
        addUserNotification(user.id, `Your withdrawal of Rp ${withdrawal.amount.toLocaleString('id-ID')} was ${status}, and your balance has been restored.`);
      }
    }
    withdrawals[withdrawalIndex].status = status;
    setStoredWithdrawals(withdrawals);
    addUserNotification(withdrawal.userId, `Your withdrawal #${withdrawalId} status updated to ${status}.`);
    return true;
  }
  return false;
};
