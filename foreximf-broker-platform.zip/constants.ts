import React from 'react';
import {
  User,
  Transaction,
  DepositTransaction,
  WithdrawalTransaction,
  TransactionType,
  TransactionStatus,
  CompanyBankInfo,
  MenuItem,
  UserWithPassword, // Import UserWithPassword
} from './types';
import {
  ChartBarIcon,
  CurrencyDollarIcon,
  CreditCardIcon,
  ArrowDownIcon,
  ShieldCheckIcon,
  Cog6ToothIcon,
  BellIcon,
  BanknotesIcon,
  WalletIcon,
  UserCircleIcon,
} from '@heroicons/react/24/outline';


// --- Mock User Data ---
export const MOCK_USERS: UserWithPassword[] = [ // Use UserWithPassword here
  {
    id: 'user-1',
    fullName: 'Amboali 89',
    username: 'amboali89', // Added username
    email: 'amboali89@gmail.com',
    phoneNumber: '081234567890',
    isAdmin: false,
    isVerified: false, // Set to false to show activation alert
    balance: 13000000, // Rp 13.000.000
    notifications: [],
    profilePictureUrl: undefined,
    password: 'password123',
  },
  {
    id: 'admin-1',
    fullName: 'Admin User',
    username: 'admin', // Added username
    email: 'admin@foreximf.com',
    phoneNumber: '08111222333',
    isAdmin: true,
    isVerified: true,
    balance: 13000000,
    notifications: [],
    profilePictureUrl: undefined,
    password: 'adminpassword',
  },
];

// --- Mock Transaction Data ---
// Empty mock data to ensure new users start with a clean slate.
export const MOCK_DEPOSITS: DepositTransaction[] = [];

export const MOCK_WITHDRAWALS: WithdrawalTransaction[] = []; // Emptied as per request

export const MOCK_TRANSACTIONS: Transaction[] = [...MOCK_DEPOSITS, ...MOCK_WITHDRAWALS];

// --- Company Bank Information (for deposit) ---
export const DEFAULT_COMPANY_BANK_INFO: CompanyBankInfo = {
  bankName: 'Bank Central Asia (BCA)',
  accountNumber: '123-456-7890',
  accountHolderName: 'PT. FOREXIMF GLOBAL',
};

// --- Dashboard Sidebar Menu Items ---
export const DASHBOARD_MENU_ITEMS: MenuItem[] = [
  // Fix: Explicitly use React.createElement for icons to ensure proper JSX parsing of className attribute
  { id: 'dashboard', name: 'Dashboard', icon: React.createElement(ChartBarIcon, { className: "w-5 h-5" }), path: '/' },
  { id: 'trade', name: 'Trade', icon: React.createElement(CurrencyDollarIcon, { className: "w-5 h-5" }), path: '/trade' },
  { id: 'deposit', name: 'Deposit', icon: React.createElement(CreditCardIcon, { className: "w-5 h-5" }), path: '/deposit' },
  { id: 'withdrawal', name: 'Withdrawal', icon: React.createElement(ArrowDownIcon, { className: "w-5 h-5" }), path: '/withdrawal' },
  { id: 'investment', name: 'Investment', icon: React.createElement(BanknotesIcon, { className: "w-5 h-5" }), path: '/investment' },
  { id: 'kyc', name: 'KYC', icon: React.createElement(UserCircleIcon, { className: "w-5 h-5" }), path: '/kyc' },
  { id: 'security', name: 'Security', icon: React.createElement(ShieldCheckIcon, { className: "w-5 h-5" }), path: '/security' },
  { id: 'setting', name: 'Setting', icon: React.createElement(Cog6ToothIcon, { className: "w-5 h-5" }), path: '/setting' },
  // Admin panel for demonstration purposes (only visible if user is an admin)
  { id: 'admin', name: 'Admin Panel', icon: React.createElement(BellIcon, { className: "w-5 h-5" }), path: '/admin' },
];

// --- Mock Market Data for Chart ---
export const MOCK_MARKET_DATA = [
  { name: 'Jan', value: 4000, pv: 2400, amt: 2400 },
  { name: 'Feb', value: 3000, pv: 1398, amt: 2210 },
  { name: 'Mar', value: 2000, pv: 9800, amt: 2290 },
  { name: 'Apr', value: 2780, pv: 3908, amt: 2000 },
  { name: 'May', value: 1890, pv: 4800, amt: 2181 },
  { name: 'Jun', value: 2390, pv: 3800, amt: 2500 },
  { name: 'Jul', value: 3490, pv: 4300, amt: 2100 },
  { name: 'Aug', value: 4200, pv: 2400, amt: 2400 },
  { name: 'Sep', value: 3800, pv: 1398, amt: 2210 },
  { name: 'Oct', value: 2500, pv: 9800, amt: 2290 },
  { name: 'Nov', value: 3100, pv: 3908, amt: 2000 },
  { name: 'Dec', value: 3900, pv: 4800, amt: 2181 },
];

// E-Wallet Options
export const E_WALLET_OPTIONS = [
  'OVO',
  'GoPay',
  'DANA',
  'LinkAja',
  'ShopeePay',
];

// Bank Options (Simplified for Indonesia)
export const BANK_OPTIONS = [
  'Bank Central Asia (BCA)',
  'Bank Mandiri',
  'Bank Rakyat Indonesia (BRI)',
  'Bank Negara Indonesia (BNI)',
  'Bank Syariah Indonesia (BSI)',
  'CIMB Niaga',
  'PermataBank',
  'BTN',
  'OCBC NISP',
  'DBS Indonesia',
  'Maybank Indonesia',
];