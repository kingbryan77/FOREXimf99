import React, { createContext, useState, useEffect, useContext, useCallback } from 'react';
import {
  DepositTransaction,
  WithdrawalTransaction,
  TransactionStatus,
  NotificationItem,
  CompanyBankInfo,
  Transaction,
  User, // Import User directly from types
} from '../types';
import * as transactionService from '../services/transactionService';
import * as authService from '../services/authService';
import { useAuth } from './AuthContext';

interface TransactionContextType {
  balance: number;
  accountMode: 'real' | 'demo'; // Added account mode
  toggleAccountMode: () => void; // Added function to toggle mode
  depositHistory: DepositTransaction[];
  withdrawalHistory: WithdrawalTransaction[];
  notifications: NotificationItem[];
  companyBankInfo: CompanyBankInfo;
  isLoadingTransactions: boolean;
  transactionError: string | null;
  addNotification: (message: string) => void;
  markNotificationAsRead: (notificationId: string) => void;
  deposit: (amount: number) => Promise<boolean>;
  withdraw: (amount: number, method: string, bankOrEwalletName: string, accountNumber: string, accountHolderName: string) => Promise<boolean>;
  // Admin simulation functions
  updateDepositStatus: (depositId: string, status: TransactionStatus) => void;
  updateWithdrawalStatus: (withdrawalId: string, status: TransactionStatus) => void;
  setCompanyBankInfo: (info: CompanyBankInfo) => void;
  // For admin panel to get all transactions
  getAllTransactions: () => Transaction[];
  // For admin panel to get all users
  getAllUsers: () => User[]; // Use imported User type
  updateUserVerification: (userId: string, isVerified: boolean) => void;
}

const TransactionContext = createContext<TransactionContextType | undefined>(undefined);

export const TransactionProvider: React.FC<React.PropsWithChildren<{}>> = ({ children }) => {
  const { user, refreshUser } = useAuth();
  const [balance, setBalance] = useState<number>(0);
  const [accountMode, setAccountMode] = useState<'real' | 'demo'>('real'); // State for account mode
  const [depositHistory, setDepositHistory] = useState<DepositTransaction[]>([]);
  const [withdrawalHistory, setWithdrawalHistory] = useState<WithdrawalTransaction[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [companyBankInfo, setCompanyBankInfoState] = useState<CompanyBankInfo>(transactionService.getCompanyBankInfo());
  const [isLoadingTransactions, setIsLoadingTransactions] = useState<boolean>(false);
  const [transactionError, setTransactionError] = useState<string | null>(null);

  const fetchTransactions = useCallback(() => {
    if (user) {
      setIsLoadingTransactions(true);
      setBalance(user.balance); // Ensure balance is always in sync with user object
      setDepositHistory(transactionService.getDepositHistory(user.id));
      setWithdrawalHistory(transactionService.getWithdrawalHistory(user.id));
      setNotifications(user.notifications.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      setIsLoadingTransactions(false);
    } else {
      setBalance(0);
      setDepositHistory([]);
      setWithdrawalHistory([]);
      setNotifications([]);
    }
  }, [user]);

  useEffect(() => {
    fetchTransactions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, user?.balance, user?.notifications]); // Re-fetch if user or their core data changes

  // Update company bank info from local storage
  useEffect(() => {
    setCompanyBankInfoState(transactionService.getCompanyBankInfo());
  }, []);

  // Listen for storage changes to keep state in sync (e.g., admin updates)
  useEffect(() => {
    const handleStorageChange = (event: StorageEvent) => {
      if (event.key?.startsWith('foreximf_')) { // Catch all relevant keys
        refreshUser(); // Refresh user data including balance and notifications
        setCompanyBankInfoState(transactionService.getCompanyBankInfo()); // Also refresh company bank info
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [refreshUser]);

  const toggleAccountMode = () => {
    setAccountMode(prevMode => (prevMode === 'real' ? 'demo' : 'real'));
  };

  const displayedBalance = accountMode === 'real' ? balance : 0;


  const addNotification = (message: string) => {
    if (user) {
      authService.addUserNotification(user.id, message);
      refreshUser(); // Trigger re-fetch of user with new notification
    }
  };

  const markNotificationAsRead = (notificationId: string) => {
    if (user) {
      authService.updateUserNotification(user.id, notificationId, true);
      refreshUser();
    }
  };

  const deposit = async (amount: number): Promise<boolean> => {
    if (accountMode === 'demo') {
      setTransactionError('Deposits are disabled in Demo mode.');
      return false;
    }
    if (!user) {
      setTransactionError('You must be logged in to deposit.');
      return false;
    }
    setIsLoadingTransactions(true);
    setTransactionError(null);
    const success = await transactionService.deposit(user.id, amount);
    if (success) {
      addNotification(`Your deposit of Rp ${amount.toLocaleString('id-ID')} is pending approval.`);
      fetchTransactions(); // Re-fetch updated history
    } else {
      setTransactionError('Deposit failed.');
    }
    setIsLoadingTransactions(false);
    return success;
  };

  const withdraw = async (
    amount: number,
    method: string,
    bankOrEwalletName: string,
    accountNumber: string,
    accountHolderName: string,
  ): Promise<boolean> => {
    if (accountMode === 'demo') {
      setTransactionError('Withdrawals are disabled in Demo mode.');
      return false;
    }
    if (!user) {
      setTransactionError('You must be logged in to withdraw.');
      return false;
    }
    if (user.balance < amount) {
      setTransactionError('Insufficient balance.');
      return false;
    }

    setIsLoadingTransactions(true);
    setTransactionError(null);
    // Crucial: The balance is immediately updated by authService.updateUserBalance called inside transactionService.withdraw
    const success = await transactionService.withdraw(
      user.id,
      amount,
      method,
      bankOrEwalletName,
      accountNumber,
      accountHolderName,
    );
    if (success) {
      addNotification(`Your withdrawal of Rp ${amount.toLocaleString('id-ID')} is pending and your balance has been adjusted.`);
      refreshUser(); // Ensure user object (and thus balance) is updated
      fetchTransactions(); // Re-fetch updated history
    } else {
      setTransactionError('Withdrawal failed.');
    }
    setIsLoadingTransactions(false);
    return success;
  };

  // Admin simulation methods
  const updateDepositStatus = (depositId: string, status: TransactionStatus) => {
    setIsLoadingTransactions(true);
    const success = transactionService.updateDepositStatus(depositId, status);
    if (success) {
      refreshUser(); // Important to refresh user for balance update
      fetchTransactions(); // Refresh transaction list
      addNotification(`Deposit ${depositId} status updated to ${status}.`);
    } else {
      setTransactionError('Failed to update deposit status.');
    }
    setIsLoadingTransactions(false);
  };

  const updateWithdrawalStatus = (withdrawalId: string, status: TransactionStatus) => {
    setIsLoadingTransactions(true);
    const success = transactionService.updateWithdrawalStatus(withdrawalId, status);
    if (success) {
      refreshUser(); // Important to refresh user for balance update
      fetchTransactions(); // Refresh transaction list
      addNotification(`Withdrawal ${withdrawalId} status updated to ${status}.`);
    } else {
      setTransactionError('Failed to update withdrawal status.');
    }
    setIsLoadingTransactions(false);
  };

  const updateCompanyBankInfo = (info: CompanyBankInfo) => {
    transactionService.setCompanyBankInfo(info);
    setCompanyBankInfoState(info);
    addNotification('Company bank information updated by Admin.'); // Admin action notification
  };

  const getAllTransactions = useCallback(() => transactionService.getAllTransactions(), []);
  const getAllUsers = useCallback(() => authService.getAllUsers(), []);
  const updateUserVerification = (userId: string, isVerified: boolean) => {
    authService.updateUserInfo({ id: userId, isVerified });
    refreshUser(); // Refresh user list for admin, and potentially current user if it's them
  };


  const value = {
    balance: displayedBalance, // Use displayed balance
    accountMode,
    toggleAccountMode,
    depositHistory,
    withdrawalHistory,
    notifications,
    companyBankInfo,
    isLoadingTransactions,
    transactionError,
    addNotification,
    markNotificationAsRead,
    deposit,
    withdraw,
    updateDepositStatus,
    updateWithdrawalStatus,
    setCompanyBankInfo: updateCompanyBankInfo,
    getAllTransactions,
    getAllUsers,
    updateUserVerification,
  };

  return <TransactionContext.Provider value={value}>{children}</TransactionContext.Provider>;
};

export const useTransactions = (): TransactionContextType => {
  const context = useContext(TransactionContext);
  if (context === undefined) {
    throw new Error('useTransactions must be used within a TransactionProvider');
  }
  return context;
};