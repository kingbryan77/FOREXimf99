import React from 'react';

export enum AuthStatus {
  UNAUTHENTICATED = 'UNAUTHENTICATED',
  AUTHENTICATED = 'AUTHENTICATED',
  LOADING = 'LOADING',
}

export interface User {
  id: string;
  fullName: string;
  username: string; // Added for username display (e.g., hidayat25)
  email: string;
  phoneNumber: string;
  isAdmin: boolean;
  isVerified: boolean;
  balance: number;
  notifications: NotificationItem[];
  profilePictureUrl?: string;
}

// Interface for user objects that include the password (used internally by authService)
export interface UserWithPassword extends User {
  password: string;
}

export interface UserProfileUpdate {
  fullName?: string;
  phoneNumber?: string;
  profilePictureUrl?: string;
  // Potentially other profile fields that can be updated by the user
}

export enum TransactionType {
  DEPOSIT = 'DEPOSIT',
  WITHDRAWAL = 'WITHDRAWAL',
}

export enum TransactionStatus {
  PENDING = 'PENDING',
  SUCCESS = 'SUCCESS',
  FAILED = 'FAILED',
  REJECTED = 'REJECTED',
  CANCELLED = 'CANCELLED',
}

export interface DepositTransaction {
  id: string;
  userId: string;
  type: TransactionType.DEPOSIT;
  amount: number;
  method: string;
  status: TransactionStatus;
  date: string;
  proofImageUrl?: string;
  companyBankInfo?: CompanyBankInfo; // Snapshot of bank info at time of deposit
}

export interface WithdrawalTransaction {
  id: string;
  userId: string;
  type: TransactionType.WITHDRAWAL;
  amount: number;
  method: string;
  bankOrEwalletName: string;
  accountNumber: string;
  accountHolderName: string;
  status: TransactionStatus;
  date: string;
}

export type Transaction = DepositTransaction | WithdrawalTransaction;

export interface CompanyBankInfo {
  bankName: string;
  accountNumber: string;
  accountHolderName: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  message: string;
  date: string;
  read: boolean;
}

export interface MenuItem {
  id: string;
  name: string;
  icon: React.ReactNode;
  path: string;
}