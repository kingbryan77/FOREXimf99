import React, { useState } from 'react';
import { EyeIcon, EyeSlashIcon } from '@heroicons/react/24/outline';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  icon?: React.ReactNode;
  error?: string;
  id: string; // Ensure id is always provided for accessibility
}

const Input: React.FC<InputProps> = ({
  label,
  icon,
  error,
  type = 'text',
  id,
  className,
  ...props
}) => {
  const [showPassword, setShowPassword] = useState(false);
  const isPasswordType = type === 'password';

  const inputType = isPasswordType && showPassword ? 'text' : type;

  return (
    <div className={`mb-4 ${className || ''}`}>
      {label && (
        <label htmlFor={id} className="block text-gray-300 text-sm font-medium mb-1">
          {label}
        </label>
      )}
      <div className="relative">
        {icon && (
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            {React.cloneElement(icon as React.ReactElement, { className: 'h-5 w-5 text-gray-400' })}
          </div>
        )}
        <input
          id={id}
          type={inputType}
          className={`block w-full px-4 py-2 bg-darkblue2 text-white border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent
            ${icon ? 'pl-10' : ''}
            ${error ? 'border-danger focus:ring-danger' : ''}
          `}
          {...props}
        />
        {isPasswordType && (
          <button
            type="button"
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-white focus:outline-none"
            onClick={() => setShowPassword(!showPassword)}
          >
            {showPassword ? (
              <EyeSlashIcon className="h-5 w-5" />
            ) : (
              <EyeIcon className="h-5 w-5" />
            )}
          </button>
        )}
      </div>
      {error && <p className="mt-1 text-sm text-danger">{error}</p>}
    </div>
  );
};

export default Input;
