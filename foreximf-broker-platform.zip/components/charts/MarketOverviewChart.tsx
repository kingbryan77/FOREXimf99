import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { MOCK_MARKET_DATA } from '../../constants';

const MarketOverviewChart: React.FC = () => {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart
        data={MOCK_MARKET_DATA}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#4B5563" /> {/* Darker grid lines */}
        <XAxis dataKey="name" stroke="#9CA3AF" /> {/* Gray axis text */}
        <YAxis stroke="#9CA3AF" />
        <Tooltip
          contentStyle={{ backgroundColor: '#1F2937', border: 'none', borderRadius: '8px' }}
          labelStyle={{ color: '#E5E7EB' }}
          itemStyle={{ color: '#A0AEC0' }}
        />
        <Line type="monotone" dataKey="value" stroke="#6366F1" activeDot={{ r: 8 }} /> {/* Primary color line */}
      </LineChart>
    </ResponsiveContainer>
  );
};

export default MarketOverviewChart;
