import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTransactions } from '../../context/TransactionContext';
import { Transaction, TransactionStatus, User } from '../../types';
import Button from '../common/Button';
import Input from '../common/Input';
import { BanknotesIcon, CreditCardIcon, BuildingLibraryIcon } from '@heroicons/react/24/outline'; // Add BuildingLibraryIcon


const AdminPanel: React.FC = () => {
  const { user } = useAuth();
  const {
    getAllUsers,
    updateUserVerification,
    getAllTransactions,
    updateDepositStatus,
    updateWithdrawalStatus,
    companyBankInfo,
    setCompanyBankInfo,
  } = useTransactions();

  const [activeTab, setActiveTab] = useState<'users' | 'transactions' | 'settings'>('users');
  const [newBankName, setNewBankName] = useState(companyBankInfo.bankName);
  const [newAccountNumber, setNewAccountNumber] = useState(companyBankInfo.accountNumber);
  const [newAccountHolderName, setNewAccountHolderName] = useState(companyBankInfo.accountHolderName);

  if (!user || !user.isAdmin) {
    return (
      <div className="container mx-auto text-center text-danger">
        Access Denied: You must be an administrator to view this page.
      </div>
    );
  }

  const users = getAllUsers();
  const transactions = getAllTransactions();

  const handleUpdateBankInfo = () => {
    setCompanyBankInfo({
      bankName: newBankName,
      accountNumber: newAccountNumber,
      accountHolderName: newAccountHolderName,
    });
    alert('Company Bank Info Updated!');
  };

  const getStatusClass = (status: TransactionStatus): string => {
    switch (status) {
      case TransactionStatus.SUCCESS:
        return 'bg-success/20 text-success';
      case TransactionStatus.PENDING:
        return 'bg-warning/20 text-warning';
      case TransactionStatus.REJECTED:
      case TransactionStatus.FAILED:
      case TransactionStatus.CANCELLED:
        return 'bg-danger/20 text-danger';
      default:
        return 'bg-gray-700 text-gray-300';
    }
  };

  return (
    <div className="container mx-auto">
      <h2 className="text-2xl sm:text-3xl font-bold text-white mb-6">Admin Panel (MOCK)</h2>
      <p className="text-gray-500 mb-8">
        This is a frontend-only simulation of an admin panel. All data and actions are handled client-side via Local Storage and do not represent real backend functionality.
      </p>

      <div className="bg-darkblue2 p-6 rounded-lg shadow-md">
        <div className="flex border-b border-gray-700 mb-6 overflow-x-auto">
          <button
            className={`px-4 py-2 text-base sm:text-lg font-medium whitespace-nowrap ${
              activeTab === 'users' ? 'text-primary border-b-2 border-primary' : 'text-gray-400 hover:text-white'
            }`}
            onClick={() => setActiveTab('users')}
          >
            Manage Users
          </button>
          <button
            className={`ml-4 px-4 py-2 text-base sm:text-lg font-medium whitespace-nowrap ${
              activeTab === 'transactions' ? 'text-primary border-b-2 border-primary' : 'text-gray-400 hover:text-white'
            }`}
            onClick={() => setActiveTab('transactions')}
          >
            Manage Transactions
          </button>
          <button
            className={`ml-4 px-4 py-2 text-base sm:text-lg font-medium whitespace-nowrap ${
              activeTab === 'settings' ? 'text-primary border-b-2 border-primary' : 'text-gray-400 hover:text-white'
            }`}
            onClick={() => setActiveTab('settings')}
          >
            Company Settings
          </button>
        </div>

        {activeTab === 'users' && (
          <div>
            <h3 className="text-xl font-semibold mb-4">All Users</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-700">
                <thead className="bg-darkblue">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">ID</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Name</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Email</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Balance</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Verified</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Admin</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {users.map((u: User) => (
                    <tr key={u.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-xs sm:text-sm text-gray-500">{u.id}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-xs sm:text-sm text-white">{u.fullName}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-xs sm:text-sm text-gray-300">{u.email}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-xs sm:text-sm text-white">Rp {u.balance.toLocaleString('id-ID')}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-xs sm:text-sm">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${u.isVerified ? 'bg-success/20 text-success' : 'bg-danger/20 text-danger'}`}>
                          {u.isVerified ? 'Yes' : 'No'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-xs sm:text-sm">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${u.isAdmin ? 'bg-primary/20 text-primary' : 'bg-gray-700 text-gray-400'}`}>
                          {u.isAdmin ? 'Yes' : 'No'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-xs sm:text-sm font-medium">
                        <Button
                          variant={u.isVerified ? 'danger' : 'primary'}
                          size="sm"
                          onClick={() => updateUserVerification(u.id, !u.isVerified)}
                          className="mr-2"
                        >
                          {u.isVerified ? 'Deactivate' : 'Activate'}
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'transactions' && (
          <div>
            <h3 className="text-xl font-semibold mb-4">All Transactions</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-700">
                <thead className="bg-darkblue">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">ID</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">User ID</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Type</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Amount</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {transactions.map((t: Transaction) => (
                    <tr key={t.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-xs sm:text-sm text-gray-500">{t.id}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-xs sm:text-sm text-gray-300">{t.userId}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-xs sm:text-sm text-white">{t.type}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-xs sm:text-sm text-white">Rp {t.amount.toLocaleString('id-ID')}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusClass(t.status)}`}>
                          {t.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-xs sm:text-sm text-gray-500">{new Date(t.date).toLocaleString()}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-xs sm:text-sm font-medium">
                        {t.status === TransactionStatus.PENDING && (
                          <>
                            <Button
                              variant="primary"
                              size="sm"
                              onClick={() => {
                                if (t.type === 'DEPOSIT') updateDepositStatus(t.id, TransactionStatus.SUCCESS);
                                else updateWithdrawalStatus(t.id, TransactionStatus.SUCCESS);
                              }}
                              className="mr-2"
                            >
                              Approve
                            </Button>
                            <Button
                              variant="danger"
                              size="sm"
                              onClick={() => {
                                if (t.type === 'DEPOSIT') updateDepositStatus(t.id, TransactionStatus.REJECTED);
                                else updateWithdrawalStatus(t.id, TransactionStatus.REJECTED);
                              }}
                            >
                              Reject
                            </Button>
                          </>
                        )}
                        {(t.status === TransactionStatus.SUCCESS || t.status === TransactionStatus.REJECTED) && (
                           <span className="text-gray-500 text-xs">Actioned</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div>
            <h3 className="text-xl font-semibold mb-4">Company Bank Information for Deposits</h3>
            <div className="bg-darkblue p-4 rounded-md border border-gray-700 mb-6">
              <Input
                id="adminBankName"
                label="Bank Name"
                type="text"
                icon={<BuildingLibraryIcon />}
                value={newBankName}
                onChange={(e) => setNewBankName(e.target.value)}
                className="mb-4"
              />
              <Input
                id="adminAccountNumber"
                label="Account Number"
                type="text"
                icon={<CreditCardIcon />}
                value={newAccountNumber}
                onChange={(e) => setNewAccountNumber(e.target.value)}
                className="mb-4"
              />
              <Input
                id="adminAccountHolderName"
                label="Account Holder Name"
                type="text"
                icon={<BanknotesIcon />}
                value={newAccountHolderName}
                onChange={(e) => setNewAccountHolderName(e.target.value)}
                className="mb-4"
              />
              <Button onClick={handleUpdateBankInfo} variant="primary" fullWidth>
                Update Bank Info
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;