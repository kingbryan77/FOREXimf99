import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { EnvelopeIcon, LockClosedIcon, PhoneIcon } from '@heroicons/react/24/outline';
import Input from '../common/Input';
import Button from '../common/Button';
import { useAuth } from '../../context/AuthContext';

const LoginForm: React.FC = () => {
  const [identifier, setIdentifier] = useState(''); // Can be email or phone number
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<{ identifier?: string; password?: string; api?: string }>({});
  const { login, isLoading, error } = useAuth();
  const navigate = useNavigate();

  const validate = () => {
    const newErrors: typeof errors = {};
    if (!identifier) newErrors.identifier = 'Email or Phone Number is required.';
    if (!password) newErrors.password = 'Password is required.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    // Use `password` directly as the second argument, consistent with `authService.login`
    const success = await login(identifier, password); 
    if (success) {
      navigate('/'); // Navigate to dashboard on successful login
    } else {
      setErrors(prev => ({ ...prev, api: error || 'Login failed. Please try again.' }));
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2 className="text-xl font-semibold mb-2">Welcome Back</h2>
      <p className="text-gray-400 mb-6">Login to your account</p>

      {errors.api && (
        <div className="bg-danger/20 text-danger p-3 rounded-md mb-4 text-sm">
          {errors.api}
        </div>
      )}

      <Input
        id="identifier"
        label="Email Address / Phone Number"
        type="text"
        placeholder="Enter your email or phone"
        icon={identifier.includes('@') ? <EnvelopeIcon /> : <PhoneIcon />}
        value={identifier}
        onChange={(e) => {
          setIdentifier(e.target.value);
          setErrors(prev => ({ ...prev, identifier: undefined, api: undefined }));
        }}
        error={errors.identifier}
      />
      <Input
        id="password"
        label="Password"
        type="password"
        placeholder="Enter your password"
        icon={<LockClosedIcon />}
        value={password}
        onChange={(e) => {
          setPassword(e.target.value);
          setErrors(prev => ({ ...prev, password: undefined, api: undefined }));
        }}
        error={errors.password}
      />

      <div className="flex justify-end mb-6">
        <Link to="/forgot-password" className="text-primary hover:underline text-sm">
          Forgot Password?
        </Link>
      </div>

      <Button type="submit" fullWidth isLoading={isLoading} disabled={isLoading}>
        Login
      </Button>

      <div className="flex items-center my-6">
        <hr className="flex-grow border-gray-700" />
        <span className="px-3 text-gray-500 text-sm">OR</span>
        <hr className="flex-grow border-gray-700" />
      </div>

      <p className="text-gray-400 text-sm">
        Don't have an account?{' '}
        <Link to="/register" className="text-primary hover:underline font-medium">
          Register Now
        </Link>
      </p>
    </form>
  );
};

export default LoginForm;