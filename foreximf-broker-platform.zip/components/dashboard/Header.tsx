import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { BellIcon, UserCircleIcon } from '@heroicons/react/24/outline';
import NotificationDropdown from './NotificationDropdown';
import ProfileDropdown from './ProfileDropdown'; // Import the new ProfileDropdown
import { useAuth } from '../../context/AuthContext';
import { useTransactions } from '../../context/TransactionContext';

const Header: React.FC = () => {
  const { user } = useAuth();
  const { balance, notifications, accountMode, toggleAccountMode } = useTransactions();
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false); // State for profile dropdown

  const unreadNotificationsCount = notifications.filter(n => !n.read).length;

  const formatCurrency = (amount: number): string => {
    return `Rp ${amount.toLocaleString('id-ID')}`;
  };

  // Static/Mock market data for header
  const marketData = [
    { name: '17420', change: '+0.64%', type: 'green' },
    { name: 'BTC', price: '89576.08', change: '-1.53%', type: 'red' },
    { name: 'ETH', price: '3071.41', change: '+0.69%', type: 'green' },
    { name: 'USDT', price: '2.38', change: '+0.23%', type: 'green' },
  ];

  return (
    <header className="fixed top-0 left-0 lg:left-64 right-0 bg-darkblue2 p-4 z-40 shadow-md">
      <div className="flex items-center justify-between">
        {/* Left Section: Logo & Market Data (Visible on larger screens) */}
        <div className="hidden lg:flex items-center space-x-4">
          <Link to="/" className="text-xl font-bold text-white whitespace-nowrap">FOREX<span className="text-primary">IMF</span></Link>
          <div className="flex items-center text-sm ml-6 space-x-4">
            {marketData.map((item, index) => (
              <div key={index} className="flex items-center">
                <span className="text-gray-400 mr-1">{item.name}</span>
                {item.price && <span className="text-white mr-1">{item.price}</span>}
                <span className={`font-semibold ${item.type === 'green' ? 'text-success' : 'text-danger'}`}>
                  {item.change}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Mobile Logo (visible on small screens) */}
        <Link to="/" className="lg:hidden text-xl font-bold text-white">FOREX<span className="text-primary">IMF</span></Link>


        {/* Right Section: Balance, Live Status, User, Notifications */}
        <div className="flex items-center space-x-4">
          <button onClick={toggleAccountMode} className="flex items-center bg-gray-700 px-3 py-1 rounded-full text-sm cursor-pointer hover:bg-gray-600 transition-colors">
            <span className="mr-2 text-gray-300">{formatCurrency(balance)}</span>
            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${accountMode === 'real' ? 'bg-success' : 'bg-blue-500'} text-white`}>
              {accountMode === 'real' ? 'Real' : 'Demo'}
            </span>
          </button>

          <div className="relative">
            <button
              onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
              className="p-2 rounded-full hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary relative"
            >
              <BellIcon className="h-6 w-6 text-gray-300" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-danger text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {unreadNotificationsCount}
                </span>
              )}
            </button>
            {isNotificationsOpen && (
              <NotificationDropdown
                notifications={notifications}
                onClose={() => setIsNotificationsOpen(false)}
              />
            )}
          </div>

          <div className="relative border-l border-gray-700 pl-4">
            <button
              onClick={() => setIsProfileOpen(!isProfileOpen)}
              className="flex items-center space-x-2 focus:outline-none"
            >
              {user?.profilePictureUrl ? (
                <img src={user.profilePictureUrl} alt="Profile" className="h-8 w-8 rounded-full object-cover" />
              ) : (
                <UserCircleIcon className="h-7 w-7 text-gray-300" />
              )}
              <span className="hidden sm:block text-gray-300 font-medium">{user?.fullName || 'Guest'}</span>
            </button>
            {isProfileOpen && <ProfileDropdown onClose={() => setIsProfileOpen(false)} />}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;