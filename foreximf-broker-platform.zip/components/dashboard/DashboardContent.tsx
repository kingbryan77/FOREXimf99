import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTransactions } from '../../context/TransactionContext';
import MarketOverviewChart from '../charts/MarketOverviewChart';
import { ArrowTrendingUpIcon, ArrowTrendingDownIcon, CurrencyDollarIcon, StarIcon } from '@heroicons/react/24/outline';

const StatCard: React.FC<{ title: string; value: string; change?: string; changeType?: 'positive' | 'negative'; icon: React.ReactNode }> = ({
  title,
  value,
  change,
  changeType,
  icon,
}) => (
  <div className="bg-darkblue2 p-6 rounded-lg shadow-md flex flex-col justify-between h-40">
    <div className="flex items-center justify-between mb-2">
      <h3 className="text-md font-medium text-gray-300">{title}</h3>
      {icon}
    </div>
    <div className="flex-grow">
      <p className="text-2xl sm:text-3xl font-bold text-white">{value}</p>
    </div>
    {change && (
      <p className={`text-sm ${changeType === 'positive' ? 'text-success' : 'text-danger'}`}>
        {change}
      </p>
    )}
  </div>
);

const DashboardContent: React.FC = () => {
  const { user } = useAuth();
  const { balance } = useTransactions(); // Correctly use balance from TransactionContext

  // Mock data for dashboard stats based on user request
  const dashboardStats = [
    {
      title: 'Total Profit',
      value: `Rp ${balance.toLocaleString('id-ID')}`, // Use dynamic balance from context
      change: 'Current balance',
      changeType: 'positive',
      icon: <ArrowTrendingUpIcon className="w-6 h-6 text-success" />,
    },
    {
      title: 'Total Loss',
      value: `Rp 0`,
      change: 'No losses recorded',
      changeType: 'positive', // Changed to positive as there's no loss
      icon: <ArrowTrendingDownIcon className="w-6 h-6 text-danger" />,
    },
    {
      title: 'Active Trades',
      value: '0', // Set to 0 as no active trading platform
      change: 'No active trades',
      changeType: 'positive',
      icon: <CurrencyDollarIcon className="w-6 h-6 text-primary" />,
    },
    {
      title: 'Win Rate',
      value: '100%',
      change: 'Perfect record',
      changeType: 'positive',
      icon: <StarIcon className="w-6 h-6 text-warning" />,
    },
  ];

  return (
    <div className="container mx-auto mt-4">
      {/* Welcome Section */}
      <div className="bg-darkblue2 p-6 rounded-lg shadow-md mb-8">
        <h2 className="text-xl sm:text-2xl font-bold text-white mb-2">Welcome back, {user?.fullName}!</h2>
        <p className="text-base text-gray-400 mb-4">{user?.email}</p>
        <p className="text-gray-500">Ready to trade today?</p>
      </div>

      {/* Statistic Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {dashboardStats.map((stat, index) => (
          <StatCard key={index} {...stat} />
        ))}
      </div>

      {/* Market Overview Chart */}
      <div className="bg-darkblue2 p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-bold text-white mb-4">Market Overview</h2>
        <div className="h-80 w-full"> {/* Responsive chart container */}
          <MarketOverviewChart />
        </div>
      </div>
    </div>
  );
};

export default DashboardContent;