import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { ArrowLeftOnRectangleIcon } from '@heroicons/react/24/outline';
import { DASHBOARD_MENU_ITEMS } from '../../constants';
import { useAuth } from '../../context/AuthContext';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const { logout, user } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const filteredMenuItems = DASHBOARD_MENU_ITEMS.filter(item => {
    if (item.id === 'admin') {
      return user?.isAdmin;
    }
    return true;
  });


  return (
    <aside
      className={`fixed inset-y-0 left-0 bg-darkblue2 w-64 p-4 flex flex-col z-40 transform ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } lg:translate-x-0 transition-transform duration-300 ease-in-out`}
    >
      <div className="flex-grow">
        <div className="text-xl font-bold text-white mb-6 hidden lg:block">FOREX<span className="text-primary">IMF</span></div>
        <nav className="space-y-2">
          {filteredMenuItems.map((item) => (
            <NavLink
              key={item.id}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center px-4 py-2 rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition-colors duration-200
                ${isActive ? 'bg-primary text-white font-semibold' : ''}`
              }
              onClick={onClose} // Close sidebar on navigation for mobile
            >
              {item.icon}
              <span className="ml-3">{item.name}</span>
            </NavLink>
          ))}
        </nav>
      </div>

      <div className="mt-auto pt-4 border-t border-gray-700">
        <button
          onClick={handleLogout}
          className="flex items-center w-full px-4 py-2 rounded-md text-gray-300 hover:bg-danger hover:text-white transition-colors duration-200"
        >
          <ArrowLeftOnRectangleIcon className="w-5 h-5" />
          <span className="ml-3">Logout</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
