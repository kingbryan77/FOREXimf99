import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Header from '../dashboard/Header';
import Sidebar from '../dashboard/Sidebar';
import { Bars3Icon, XMarkIcon, InformationCircleIcon } from '@heroicons/react/24/outline';
import { useAuth } from '../../context/AuthContext';

const DashboardLayout: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { user } = useAuth();

  return (
    <div className="flex min-h-screen bg-darkblue text-white">
      {/* Mobile Sidebar Toggle */}
      <button
        className="lg:hidden fixed top-4 left-4 z-50 p-2 rounded-md bg-darkblue2 text-white focus:outline-none focus:ring-2 focus:ring-primary"
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
      >
        {isSidebarOpen ? <XMarkIcon className="h-6 w-6" /> : <Bars3Icon className="h-6 w-6" />}
      </button>

      {/* Sidebar */}
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col lg:ml-64 transition-all duration-300 ease-in-out">
        <Header />
        <main className="flex-1 p-4 pt-20 lg:pt-4">
          {/* Account Activation Alert */}
          {!user?.isVerified && (
            <div className="bg-danger/80 text-white p-4 rounded-lg shadow-lg mb-6 flex items-start">
              <InformationCircleIcon className="h-6 w-6 mr-3 flex-shrink-0" />
              <div>
                <h3 className="font-bold">Perhatian</h3>
                <p className="text-sm">
                  Soleh {user?.fullName}, silahkan lakukan pembayaran untuk mengaktifkan akun anda.
                </p>
              </div>
            </div>
          )}
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;