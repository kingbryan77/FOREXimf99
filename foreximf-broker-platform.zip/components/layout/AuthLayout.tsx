import React from 'react';
import { Outlet } from 'react-router-dom';

const AuthLayout: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-900 to-indigo-950 text-white p-4">
      <div className="w-full max-w-md bg-darkblue2 rounded-lg shadow-xl p-8 sm:p-10 text-center">
        <div className="text-3xl font-bold text-white mb-2">FOREX<span className="text-primary">IMF</span></div>
        <p className="text-gray-400 mb-8">Trade with Confidence</p>
        <Outlet />
        <p className="mt-8 text-gray-500 text-sm">
          &copy; 2024 FOREXIMF. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default AuthLayout;
