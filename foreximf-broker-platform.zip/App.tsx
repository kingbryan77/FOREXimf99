import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { TransactionProvider } from './context/TransactionContext';

import AuthLayout from './components/layout/AuthLayout';
import DashboardLayout from './components/layout/DashboardLayout';
import LoginForm from './components/auth/LoginForm';
import RegisterForm from './components/auth/RegisterForm';
import DashboardContent from './components/dashboard/DashboardContent';
import DepositForm from './components/transactions/DepositForm';
import WithdrawalForm from './components/transactions/WithdrawalForm';
import DepositHistory from './components/transactions/DepositHistory';
import WithdrawalHistory from './components/transactions/WithdrawalHistory';
import AdminPanel from './components/admin/AdminPanel';
import TradePage from './components/pages/TradePage';
import InvestmentPage from './components/pages/InvestmentPage';
import KycPage from './components/pages/KycPage';
import SecurityPage from './components/pages/SecurityPage';
import SettingPage from './components/pages/SettingPage';


const AppRoutes: React.FC = () => {
  const { status } = useAuth();

  if (status === 'LOADING') {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-900 to-indigo-950 text-white">
        <div className="text-xl font-semibold">Loading application...</div>
      </div>
    );
  }

  return (
    <Router>
      <Routes>
        {status === 'UNAUTHENTICATED' ? (
          <Route path="/" element={<AuthLayout />}>
            <Route index element={<LoginForm />} />
            <Route path="register" element={<RegisterForm />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        ) : (
          <Route path="/" element={<DashboardLayout />}>
            <Route index element={<DashboardContent />} />
            <Route path="trade" element={<TradePage />} />
            <Route path="deposit" element={<DepositForm />} />
            <Route path="withdrawal" element={<WithdrawalForm />} />
            <Route path="deposit-history" element={<DepositHistory />} />
            <Route path="withdrawal-history" element={<WithdrawalHistory />} />
            <Route path="investment" element={<InvestmentPage />} />
            <Route path="kyc" element={<KycPage />} />
            <Route path="security" element={<SecurityPage />} />
            <Route path="setting" element={<SettingPage />} />
            <Route path="admin" element={<AdminPanel />} /> {/* Admin route */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        )}
      </Routes>
    </Router>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <TransactionProvider>
        <AppRoutes />
      </TransactionProvider>
    </AuthProvider>
  );
};

export default App;
